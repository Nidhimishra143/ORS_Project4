package com.raystec.proj4.exception;

public class ApplicationException extends Exception {

	public ApplicationException(String msg) {
		super(msg);
	}
}
