/**
 * 
 */
/**
 * @author HP
 *
 */
package com.raystec.proj4.exception;