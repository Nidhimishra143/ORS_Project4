package com.raystec.proj4.exception;

public class DatabaseException extends Exception {

	public DatabaseException(String msg) {
		super(msg);
	}
}
