package com.raystec.proj4.bean;

public interface DropdownListBean {
	public String getkey();
	public String getvalue();
}
